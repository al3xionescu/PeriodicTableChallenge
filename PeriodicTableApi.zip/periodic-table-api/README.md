# Periodic Table API

A Spring Boot application that serves information about the periodic table elements from a JSON data file.

## Features

- **List all elements**: Basic info (name, atomic number).
- **Filter by group**: Retrieve elements by group number (e.g., group 13).
- **Element details**: Get detailed info by atomic number including name and alternative name.

## Tech Stack

- Java 17+
- Spring Boot
- Jackson (for JSON parsing)
- JUnit 5 (for testing)

## Endpoints

### GET `/api/elements`
Returns a list of all elements:
```json
[
  { "name": "Hydrogen", "atomicNumber": 1 },
  { "name": "Helium", "atomicNumber": 2 },
  ...
]
```

### GET `/api/elements/group/{group}`
Returns elements that belong to the specified group (e.g., `13`).

### GET `/api/elements/{atomicNumber}`
Returns detailed info for the element with that atomic number:
```json
{
  "atomicNumber": "13",
  "name": "Aluminum",
  "alternativeName": "aluminum (US)"
}
```

## Project Structure

- `controller/` Exposes REST endpoints
- `service/` Handles business logic
- `repository/` Loads data from JSON
- `model/` Defines the `Element` object
- `resources/` Contains `periodic_table.json` data
- `test/` Basic test for service layer

## Testing

Run unit tests:
```bash
./mvnw test
```

## Setup

1. Java 17+ installed
2. Run the app:
```bash
./mvnw spring-boot:run
```

## Design Considerations

- The JSON file is loaded once on application start for performance.
- Graceful fallback for missing fields like `alternativeName`.
- The API is designed for future expansion, including DB support or search features.

---