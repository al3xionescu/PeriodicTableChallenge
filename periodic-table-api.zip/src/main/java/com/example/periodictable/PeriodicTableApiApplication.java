
package com.example.periodictable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeriodicTableApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(PeriodicTableApiApplication.class, args);
    }
}
