
package com.example.periodictable.controller;

import com.example.periodictable.model.Element;
import com.example.periodictable.service.ElementService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/elements")
public class ElementController {
    private final ElementService service;

    public ElementController(ElementService service) {
        this.service = service;
    }

    @GetMapping
    public List<Map<String, Object>> getAllElements() {
        return service.getAllElements();
    }

    @GetMapping("/group/{group}")
    public List<Element> getElementsByGroup(@PathVariable String group) {
        return service.getElementsByGroup(group);
    }

    @GetMapping("/{atomicNumber}")
    public Map<String, String> getElementDetails(@PathVariable int atomicNumber) {
        Optional<Map<String, String>> details = service.getElementDetails(atomicNumber);
        return details.orElseThrow(() -> new RuntimeException("Element not found"));
    }
}
