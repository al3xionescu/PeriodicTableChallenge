
package com.example.periodictable.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Element {
    @JsonProperty("name")
    private String name;

    @JsonProperty("atomic_number")
    private int atomicNumber;

    @JsonProperty("group_block")
    private String groupBlock;

    @JsonProperty("alternative_name")
    private String alternativeName;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAtomicNumber() { return atomicNumber; }
    public void setAtomicNumber(int atomicNumber) { this.atomicNumber = atomicNumber; }

    public String getGroupBlock() { return groupBlock; }
    public void setGroupBlock(String groupBlock) { this.groupBlock = groupBlock; }

    public String getAlternativeName() { return alternativeName; }
    public void setAlternativeName(String alternativeName) { this.alternativeName = alternativeName; }
}
