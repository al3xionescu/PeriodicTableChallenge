
package com.example.periodictable.repository;

import com.example.periodictable.model.Element;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.io.InputStream;
import java.util.*;

@Repository
public class ElementRepository {
    private final List<Element> elements = new ArrayList<>();

    @PostConstruct
    public void init() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            InputStream is = getClass().getClassLoader().getResourceAsStream("periodic_table.json");
            List<Element> loaded = mapper.readValue(is, new TypeReference<List<Element>>() {});
            elements.addAll(loaded);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load periodic table data", e);
        }
    }

    public List<Element> getAll() {
        return elements;
    }
}
