
package com.example.periodictable.service;

import com.example.periodictable.model.Element;
import com.example.periodictable.repository.ElementRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ElementService {
    private final ElementRepository repository;

    public ElementService(ElementRepository repository) {
        this.repository = repository;
    }

    public List<Map<String, Object>> getAllElements() {
        return repository.getAll().stream()
                .map(e -> Map.of("name", e.getName(), "atomicNumber", e.getAtomicNumber()))
                .collect(Collectors.toList());
    }

    public List<Element> getElementsByGroup(String group) {
        return repository.getAll().stream()
                .filter(e -> Optional.ofNullable(e.getGroupBlock())
                        .map(g -> g.contains(group))
                        .orElse(false))
                .collect(Collectors.toList());
    }

    public Optional<Map<String, String>> getElementDetails(int atomicNumber) {
        return repository.getAll().stream()
                .filter(e -> e.getAtomicNumber() == atomicNumber)
                .findFirst()
                .map(e -> Map.of(
                        "atomicNumber", String.valueOf(e.getAtomicNumber()),
                        "name", e.getName(),
                        "alternativeName", 
                            (e.getAlternativeName() == null || e.getAlternativeName().equalsIgnoreCase("n/a")) 
                                ? "none" : e.getAlternativeName()
                ));
    }
}
