
package com.example.periodictable;

import com.example.periodictable.service.ElementService;
import com.example.periodictable.repository.ElementRepository;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class ElementServiceTests {

    private final ElementService service;

    public ElementServiceTests(ElementRepository repository) {
        this.service = new ElementService(repository);
    }

    @Test
    void testGetElementDetails() {
        Optional<?> result = service.getElementDetails(1); // Hydrogen
        assertTrue(result.isPresent());
        assertEquals("Hydrogen", ((java.util.Map<?, ?>) result.get()).get("name"));
    }
}
